from brain_games.scripts.cli import run


def main():
    welcome_text = '''Welcome to the Brain Games!
Answer 'yes' if number even otherwise answer 'no'.
'''
    print(welcome_text)
    run()
