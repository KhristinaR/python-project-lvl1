from cli import run
def main():
  print('Welcome to the Brain Games!')
  run()
