from brain_games.scripts.play import play
from brain_games.scripts.questions import questions

def main():
    play(questions)
