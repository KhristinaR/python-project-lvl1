first_question = 15
second_question = 6
third_question = 7
questions = (first_question, second_question, third_question)
print(questions)
