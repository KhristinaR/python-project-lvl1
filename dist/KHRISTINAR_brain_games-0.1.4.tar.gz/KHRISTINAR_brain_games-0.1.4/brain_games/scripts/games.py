from brain_games.scripts.cli import run

def main():
  print('Welcome to the Brain Games!')
  run()
